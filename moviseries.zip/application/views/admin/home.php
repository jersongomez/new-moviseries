<?php require_once 'base.php' ?>

<?php startblock('title') ?>Administracion<?php endblock() ?>


<?php startblock('main-content') ?>

    <div class="container text-center">
        <hr>
        <img src="/assets/img/logo.png" alt="">

        <h2>Bienvenido Administrador de Moviseries</h2>

        <h3>NOTA: Por seguridad todas las acciones realizadas por un administrador son guardadas y enviadas al web master</h3>
        <hr>
    </div>

<?php endblock() ?>

